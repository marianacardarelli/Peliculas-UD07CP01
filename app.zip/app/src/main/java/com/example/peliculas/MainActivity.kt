package com.example.peliculas

import android.content.Intent
import android.os.Bundle
import android.util.TypedValue
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.peliculas.adapter.PeliculaAdapter
import com.example.peliculas.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val listaPeliculas: MutableList<Pelicula> = mutableListOf()
    private lateinit var adapter: PeliculaAdapter
    private lateinit var layoutManager: LinearLayoutManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            // Altura de la barra de acción (para que no tape el contenido)
            val tv = TypedValue()
            theme.resolveAttribute(androidx.appcompat.R.attr.actionBarSize, tv, true)
            val barra = TypedValue.complexToDimensionPixelSize(tv.data, resources.displayMetrics)
            v.setPadding(systemBars.left, systemBars.top + barra, systemBars.right, systemBars.bottom)
            insets
        }

        // 1. Cargar los datos (una copia de la lista original)
        listaPeliculas.addAll(PeliculaProvider.cargarLista())

        // 2. Configurar el RecyclerView
        layoutManager = LinearLayoutManager(this)
        binding.rvPeliculas.layoutManager = layoutManager
        binding.rvPeliculas.setHasFixedSize(true)
        binding.rvPeliculas.itemAnimator = DefaultItemAnimator()

        // 3. Crear el adapter y pasarle la lista
        adapter = PeliculaAdapter { pelicula -> onItemSelected(pelicula) }
        binding.rvPeliculas.adapter = adapter
        adapter.submitList(listaPeliculas.toList())
    }

    private fun onItemSelected(pelicula: Pelicula) {
        val intent = Intent(this, DetalleActivity::class.java)
        intent.putExtra("pelicula", pelicula)
        startActivity(intent)
    }
}